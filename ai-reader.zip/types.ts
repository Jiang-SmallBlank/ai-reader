export type ViewState = 'landing' | 'dashboard' | 'reader' | 'report' | 'profile' | 'settings';

export interface Book {
  id: string;
  title: string;
  author: string;
  coverUrl: string;
  progress: number;
  lastRead?: string;
  category?: string;
  isFinished?: boolean;
}

export interface ReadingStat {
  day: string;
  minutes: number;
}

export interface Insight {
  id: string;
  type: 'concept' | 'quote' | 'habit';
  bookTitle: string;
  content: string;
  subText?: string;
}
